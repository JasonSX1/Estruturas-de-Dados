package com.ed.cinemamanagementsystem

class Data {

    public lateinit var path:String

    companion object {
        lateinit var username: String
    }
}